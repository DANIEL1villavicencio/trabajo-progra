package trabajo;

import javax.swing.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Parqueadero parqueadero = new Parqueadero();
        ArrayList<Carro> carros = new ArrayList<>();
        int opcion;
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el 1 para ingresar uncarro,2 dar salida a un carro, 3 para ingresos del parqueadero, 4 puestos disponibles, 5 avanzar el reloj del parqueadero o 6 para cambiar tarifa o 7 para metodo 1, 8 para metodo 2 o 9 para salir del programa"));
            switch (opcion) {
                case 1:
                    String placa = JOptionPane.showInputDialog("Ingrese el placa del carro");
                    Carro carro = new Carro(placa, parqueadero.darHoraActual());
                    parqueadero.entrarCarro(carro.darPlaca());
                    carros.add(carro);

                    break;
                case 2:
                    String placaSacar = JOptionPane.showInputDialog("Ingrese el placa del carro para retirarlo");
                    parqueadero.sacarCarro(placaSacar);
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "informe de los carros ingresados"  + "\n");
                    for (Carro carro1 : carros) {
                        JOptionPane.showMessageDialog(null, "placa del carro " + carro1.darPlaca() + "hora de llegada " + carro1.darHoraLlegada() + "\n");
                    }
                    break;
                case 4:
                    parqueadero.calcularPuestosLibres();
                    break;
                case 5:
                    parqueadero.darHoraActual();
                    parqueadero.avanzarHora();
                    break;
                case 6:
                    parqueadero.cambiarTarifa(3);
                    break;
                case 7:
                    parqueadero.metodo1();
                    break;
                case 8:
                    parqueadero.metodo2();
                    break;
                case 9:
                    JOptionPane.showInputDialog(null, "fin del programa");
                    break;
                default:
                    JOptionPane.showInputDialog(null, "no existe esta opcion");
                    break;
            }
        } while (opcion != 9);
    }
}